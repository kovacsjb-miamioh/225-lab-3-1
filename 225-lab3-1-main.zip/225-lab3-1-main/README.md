# 225-lab3-1
CI/CD pipeline Example using a Jenkinsfile.  Deployment is to __NodePort 32000 on ClusterIP__.

1) Create a new blank repository in your GitHub account using the lab name above.
2) Copy the URL of this repository and paste it into your repository.
3) View each file, and make changes where it is commented.
4) Run your pipeline.
5) Demonstrate your changes to the code in your video, and show the resulting web page.
